import java.util.Scanner;

public class Teste {
    private String[] questoes;
    private String dataGeracao;
    private String discipina;

    public Teste(String[] questoes, String dataGeracao, String disciplina) {
        this.questoes = questoes;
        this.dataGeracao = dataGeracao;
        this.discipina = disciplina;
    }

    public String getDiscipina() {
        return discipina;
    }

    public void setDiscipina(String discipina) {
        this.discipina = discipina;
    }

    public String getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(String dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public String[] getQuestoes() {
        return questoes;
    }

    public void setQuestoes(String[] questoes) {
        this.questoes = questoes;
    }

}

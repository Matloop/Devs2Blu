public class Questao {
    private String enunciado;
    private int bimestre;
    private String gabarito;
    private String materia;

    public String getGabarito() {
        return gabarito;
    }

    public void setGabarito(String gabarito) {
        this.gabarito = gabarito;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public int getBimestre() {
        return bimestre;
    }

    public void setBimestre(int bimestre) {
        this.bimestre = bimestre;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public Questao(String enunciado, int bimestre, String gabarito, String materia) {
        this.enunciado = enunciado;
        this.bimestre = bimestre;
        this.gabarito = gabarito;
        this.materia = materia;
    }
}
